package com.ashes.ballassist

import android.app.*
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import kotlin.math.cos
import kotlin.math.sin

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var guide: GuideView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var angle = -90f
    private var showBank = false
    private var guideVisible = true
    private val channelId = "8ball_assist_overlay"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        startForeground(7, notification())
        addOverlay()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "8Ball Assist", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }
    private fun notification(): Notification {
        val stop = PendingIntent.getService(this, 1, Intent(this, AimOverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
            .setContentTitle("8Ball Assist is running").setContentText("Your manual aiming guide is active")
            .setSmallIcon(android.R.drawable.ic_menu_compass).addAction(Notification.Action.Builder(null, "Stop", stop).build()).build()
        else Notification.Builder(this).setContentTitle("8Ball Assist").setSmallIcon(android.R.drawable.ic_menu_compass).build()
    }

    private fun lp(type: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun addOverlay() {
        guide = GuideView().also { wm.addView(it, lp()) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 8, 10, 8)
            setBackgroundColor(0xDD101820.toInt())
        }
        val header = TextView(this).apply { text = "8BALL ASSIST  ⋮"; textSize = 14f; setTextColor(Color.WHITE); setPadding(8, 8, 8, 8) }
        header.setOnTouchListener(DragTouch())
        bar.addView(header)
        val row1 = LinearLayout(this)
        row1.addView(btn("− 5°") { angle -= 5f; refresh() })
        row1.addView(btn("+ 5°") { angle += 5f; refresh() })
        row1.addView(btn("Bank") { showBank = !showBank; refresh() })
        bar.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(btn("Hide lines") { guideVisible = !guideVisible; refresh() })
        row2.addView(btn("Close") { stopSelf() })
        bar.addView(row2)
        panelParams = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 100 }
        panel = bar
        wm.addView(bar, panelParams)
    }

    private fun btn(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; isAllCaps = false; setPadding(4, 0, 4, 0); setOnClickListener { action() }
    }
    private fun refresh() { guide?.invalidate() }

    private inner class DragTouch : View.OnTouchListener {
        private var sx = 0f; private var sy = 0f; private var ox = 0; private var oy = 0
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val p = panelParams ?: return false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; return true }
                MotionEvent.ACTION_MOVE -> { p.x = ox + (e.rawX - sx).toInt(); p.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(panel, p); return true }
            }
            return true
        }
    }

    private inner class GuideView : View(this@AimOverlayService) {
        private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.CYAN; strokeWidth = 5f; style = Paint.Style.STROKE }
        private val ghost = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFD54F.toInt(); strokeWidth = 3f; style = Paint.Style.STROKE }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        override fun onDraw(c: Canvas) {
            super.onDraw(c)
            if (!guideVisible) return
            val cx = width * .50f; val cy = height * .58f
            val rad = Math.toRadians(angle.toDouble())
            val dx = cos(rad).toFloat(); val dy = sin(rad).toFloat()
            val length = width * .43f
            c.drawLine(cx, cy, cx + dx * length, cy + dy * length, line)
            c.drawCircle(cx, cy, 9f, dot)
            c.drawCircle(cx + dx * length, cy + dy * length, 7f, line)
            if (showBank) {
                val wallX = if (dx >= 0) width.toFloat() - 12f else 12f
                val t = (wallX - cx) / dx
                val hitY = cy + dy * t
                if (t > 0 && hitY in 12f..(height - 12f)) {
                    c.drawLine(cx, cy, wallX, hitY, line)
                    c.drawLine(wallX, hitY, wallX - dx * length * .7f, hitY + dy * length * .7f, ghost)
                    c.drawCircle(wallX, hitY, 6f, ghost)
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf()
        return START_STICKY
    }
    override fun onDestroy() {
        try { guide?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        guide = null; panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
